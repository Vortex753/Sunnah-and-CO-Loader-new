import { createFileRoute, Link } from "@tanstack/react-router";
import { BookOpen, ShieldCheck, Truck, Heart, Sparkles, Users } from "lucide-react";
import { Button } from "@/components/ui/button";
import banner from "@/assets/about-banner.jpg";
import quran from "@/assets/about-quran.jpg";
import tasbih from "@/assets/about-tasbih.jpg";
import abaya from "@/assets/about-abaya.jpg";
import thobe from "@/assets/about-thobe.jpg";

export const Route = createFileRoute("/about")({
  head: () => ({
    meta: [
      { title: "About Us — Sunnah & Co." },
      { name: "description", content: "The story and values behind Sunnah & Co., your trusted Islamic store." },
      { property: "og:title", content: "About Us — Sunnah & Co." },
      { property: "og:description", content: "The story and values behind Sunnah & Co." },
    ],
  }),
  component: About,
});

const offer: { t: string; d: string; img?: string; to: string; group: string }[] = [
  { t: "Books", d: "Qur'an, Tafsir, rulings of the Shariyah and the works of trusted scholars, in print and as e-books.", img: quran, to: "/products", group: "Islamic Books" },
  { t: "Men", d: "Thobes, jubbahs, qameez, head wear and Sunnah essentials for the everyday Muslim man.", img: thobe, to: "/products", group: "Thobes/Islamic Wear" },
  { t: "Women", d: "Abayas, prayer dresses, hijaabs and modest accessories chosen for comfort and haya.", img: abaya, to: "/products", group: "Prayer Dress/Islamic Wear" },
  { t: "Accessories", d: "Tasbeeh, atar, miswak and the small things that make worship and daily life easier.", img: tasbih, to: "/products", group: "General Accessories" },
];

const values = [
  { i: ShieldCheck, t: "Authenticity", d: "Sourced from reputable publishers and artisans across the Muslim world." },
  { i: Sparkles, t: "Quality", d: "Every product is checked before it leaves our warehouse." },
  { i: Heart, t: "Sincerity", d: "We build this store with the intention of serving the ummah and earning the pleasure of Allah." },
  { i: Users, t: "Family first", d: "From Kids Books to children's Islamic wear, we help families raise the next generation upon the Sunnah." },
  { i: BookOpen, t: "Knowledge", d: "Honest, clear descriptions so you always know exactly what you are buying." },
  { i: Truck, t: "Service", d: "Track every step of your order, from our store to your door." },
];

function About() {
  return (
    <div>
      <section className="relative" data-hero>
        <img src={banner} alt="Islamic essentials" className="h-[360px] w-full object-cover" />
        <div className="absolute inset-0 bg-gradient-to-r from-foreground/90 via-foreground/65 to-foreground/20" />
        <div className="absolute inset-0 flex items-center px-6 md:px-16">
          <div className="max-w-2xl text-background">
            <p className="text-sm uppercase tracking-[0.3em] text-gold">About us</p>
            <h1 className="mt-3 font-display text-5xl font-semibold leading-tight md:text-6xl">Bringing the Sunnah into everyday life</h1>
          </div>
        </div>
      </section>

      <section className="mx-auto grid max-w-6xl items-center gap-10 px-6 py-16 md:grid-cols-2">
        <div>
          <p className="text-sm uppercase tracking-[0.3em] text-gold">Our story</p>
          <h2 className="mt-2 font-display text-4xl">Made to make authentic easy to find</h2>
          <p className="mt-5 text-muted-foreground">
            Sunnah &amp; Co. began with a simple frustration: finding genuine Islamic products should not mean searching a dozen places and wondering what is
            authentic. We set out to bring everything together in one trusted store, from books of knowledge to garments like the jubbah, thobe and abaya,
            and Sunnah essentials like miswak, surma and atar.
          </p>
          <p className="mt-4 text-muted-foreground">
            As an import and export business, we work directly with publishers, tailors and makers, so our customers receive well-made products at fair
            prices. Every item is chosen with care, because what you wear, read and use each day should reflect your faith.
          </p>
        </div>
        <img src={tasbih} alt="Tasbeeh, atar and miswak" loading="lazy" className="h-[380px] w-full rounded-lg object-cover shadow-md" />
      </section>

      <section className="bg-secondary px-6 py-16">
        <div className="mx-auto grid max-w-6xl gap-6 md:grid-cols-2">
          <div className="rounded-lg border-t-4 border-gold bg-card p-8 shadow-sm">
            <h3 className="font-display text-3xl text-primary">Our mission</h3>
            <p className="mt-3 text-muted-foreground">To make authentic Islamic books, clothing and Sunnah essentials accessible to every Muslim household, with honesty, quality and care at every step.</p>
          </div>
          <div className="rounded-lg border-t-4 border-gold bg-card p-8 shadow-sm">
            <h3 className="font-display text-3xl text-primary">Our vision</h3>
            <p className="mt-3 text-muted-foreground">A store families trust for generations, where the Sunnah is part of everyday life, from the books on the shelf to the clothes in the wardrobe.</p>
          </div>
        </div>
      </section>

      <section className="mx-auto max-w-6xl px-6 py-16">
        <p className="text-sm uppercase tracking-[0.3em] text-gold">What we offer</p>
        <h2 className="mt-2 font-display text-4xl">Something for every member of the family</h2>
        <div className="mt-8 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
          {offer.map((o) => (
            <Link key={o.t} to={o.to} search={{ group: o.group }} className="group overflow-hidden rounded-lg border bg-card shadow-sm transition-shadow hover:shadow-md">
              <img src={o.img} alt={o.t} loading="lazy" className="h-48 w-full object-cover transition-transform duration-500 group-hover:scale-105" />
              <div className="p-5">
                <h3 className="font-display text-2xl text-primary">{o.t}</h3>
                <p className="mt-2 text-sm text-muted-foreground">{o.d}</p>
              </div>
            </Link>
          ))}
        </div>
        <p className="mt-6 text-sm text-muted-foreground">We also have a Kids section, with Islamic wear and children's books and e-books, so the whole family is covered.</p>
      </section>

      <section className="bg-secondary px-6 py-16">
        <div className="mx-auto max-w-6xl">
          <p className="text-sm uppercase tracking-[0.3em] text-gold">What we stand for</p>
          <h2 className="mt-2 font-display text-4xl">Our values</h2>
          <div className="mt-8 grid gap-6 md:grid-cols-2 lg:grid-cols-3">
            {values.map(({ i: I, t, d }) => (
              <div key={t} className="rounded-lg border-t-4 border-gold bg-card p-6 shadow-sm">
                <I className="h-6 w-6 text-gold" />
                <h3 className="mt-3 font-display text-2xl text-primary">{t}</h3>
                <p className="mt-2 text-sm text-muted-foreground">{d}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="mx-auto max-w-6xl px-6 py-16">
        <p className="text-sm uppercase tracking-[0.3em] text-gold">How it works</p>
        <h2 className="mt-2 font-display text-4xl">From our shelves to your door</h2>
        <div className="mt-8 grid gap-6 md:grid-cols-3">
          {[
            ["1", "Carefully sourced", "We choose trusted publishers, tailors and makers, and only stock what we would be happy to give our own family."],
            ["2", "Checked in store", "Each order is inspected and packed at our store and warehouse before it is dispatched."],
            ["3", "Tracked to you", "Follow your order through every stage, and leave a review once it arrives. E-books are available to download right after purchase."],
          ].map(([n, t, d]) => (
            <div key={n} className="flex gap-4">
              <span className="flex h-12 w-12 shrink-0 items-center justify-center rounded-full border-2 border-gold font-display text-xl text-primary">{n}</span>
              <div>
                <h3 className="font-display text-2xl">{t}</h3>
                <p className="mt-1 text-sm text-muted-foreground">{d}</p>
              </div>
            </div>
          ))}
        </div>
      </section>

      <section className="bg-foreground px-6 py-16 text-center text-background">
        <h2 className="mx-auto max-w-2xl font-display text-4xl">May Allah accept it from us, and make it a means of benefit for you.</h2>
        <p className="mx-auto mt-4 max-w-xl text-background/70">Questions, requests or a product you cannot find? We would love to hear from you.</p>
        <div className="mt-8 flex justify-center gap-3">
          <Button asChild size="lg" className="bg-gold text-gold-foreground hover:bg-gold/90"><Link to="/">Shop now</Link></Button>
          <Button asChild size="lg" variant="outline" className="border-background/50 bg-transparent text-background hover:bg-background/10 hover:text-background"><Link to="/contact">Get in touch</Link></Button>
        </div>
      </section>
    </div>
  );
}
