import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import { toast } from "sonner";
import { useStore } from "@/lib/store";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";

export const Route = createFileRoute("/account")({
  head: () => ({
    meta: [
      { title: "My Account — Sunnah & Co." },
      { name: "description", content: "Manage your profile and delivery addresses." },
      { property: "og:title", content: "My Account — Sunnah & Co." },
      { property: "og:description", content: "Manage your account." },
    ],
  }),
  component: Account,
});

function Account() {
  const { user, updateUser } = useStore();
  const [draft, setDraft] = useState<string[] | null>(null);
  if (!user) return <div className="py-24 text-center"><Link to="/signin" className="text-primary">Sign in</Link> to view your account.</div>;
  const addrs = draft ?? user.addresses;

  return (
    <div className="mx-auto max-w-3xl px-6 py-10">
      <h1 className="font-display text-5xl">My Account</h1>
      <div className="mt-8 grid gap-4 rounded-lg border bg-card p-6 text-sm sm:grid-cols-2">
        <div><p className="text-muted-foreground">Name</p><p className="font-medium">{user.firstName} {user.lastName}</p></div>
        <div><p className="text-muted-foreground">Username</p><p className="font-medium">{user.username}</p></div>
        <div><p className="text-muted-foreground">Email</p><p className="font-medium">{user.email}</p></div>
        <div><p className="text-muted-foreground">Phone</p><p className="font-medium">{user.phone}</p></div>
      </div>

      <div className="mt-8 rounded-lg border-t-4 border-gold bg-card p-6 shadow-sm">
        <h2 className="font-display text-2xl">Delivery addresses <span className="text-sm text-muted-foreground">(max 2)</span></h2>
        <div className="mt-4 space-y-4">
          {addrs.map((a, i) => (
            <div key={i}>
              <div className="mb-1 flex items-center justify-between text-sm font-medium">
                Address {i + 1}{i === 0 && <span className="text-xs text-gold">Default</span>}
                {i === 1 && <button className="text-xs text-destructive" onClick={() => setDraft([addrs[0] ?? ""])}>Remove</button>}
              </div>
              <Textarea maxLength={300} value={a} onChange={(e) => setDraft(addrs.map((x, j) => (j === i ? e.target.value : x)))} />
            </div>
          ))}
        </div>
        <div className="mt-4 flex gap-2">
          {addrs.length < 2 && <Button variant="outline" onClick={() => setDraft([...addrs, ""])}>Add second address</Button>}
          <Button
            onClick={() => {
              const clean = addrs.map((a) => a.trim());
              if (clean.some((a) => a.length < 5)) { toast.error("Each address needs at least 5 characters."); return; }
              updateUser({ addresses: clean });
              setDraft(null);
              toast.success("Addresses saved");
            }}
          >
            Save addresses
          </Button>
        </div>
      </div>
    </div>
  );
}
