import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { z } from "zod";
import { toast } from "sonner";
import { useStore } from "@/lib/store";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";

export const Route = createFileRoute("/signup")({
  head: () => ({
    meta: [
      { title: "Create Account — Sunnah & Co." },
      { name: "description", content: "Create your Sunnah & Co. account to shop and track orders." },
      { property: "og:title", content: "Create Account — Sunnah & Co." },
      { property: "og:description", content: "Create your account." },
    ],
  }),
  component: SignUp,
});

const schema = z.object({
  firstName: z.string().trim().min(1, "First name is required").max(50),
  lastName: z.string().trim().min(1, "Last name is required").max(50),
  username: z.string().trim().min(3, "Username must be at least 3 characters").max(30).regex(/^[a-zA-Z0-9_.]+$/, "Username can only use letters, numbers, _ and ."),
  phone: z.string().trim().min(7, "Enter a valid phone number").max(20),
  email: z.string().trim().email("Enter a valid email").max(255),
  address: z.string().trim().min(5, "Delivery address is required").max(300),
  password: z.string().min(6, "Password must be at least 6 characters").max(100),
});

function SignUp() {
  const { signUp } = useStore();
  const navigate = useNavigate();
  const [f, setF] = useState({ firstName: "", lastName: "", username: "", phone: "", email: "", address: "", password: "" });
  const set = (k: keyof typeof f) => (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => setF({ ...f, [k]: e.target.value });

  return (
    <div className="flex justify-center px-6 py-16">
      <form
        className="w-full max-w-lg space-y-4 rounded-lg border-t-4 border-gold bg-card p-8 shadow-sm"
        onSubmit={(e) => {
          e.preventDefault();
          const r = schema.safeParse(f);
          if (!r.success) { toast.error(r.error.issues[0]?.message ?? "Invalid form"); return; }
          const { address, ...rest } = r.data;
          const err = signUp({ ...rest, addresses: [address] });
          if (err) { toast.error(err); return; }
          toast.success("Account created — welcome!");
          navigate({ to: "/" });
        }}
      >
        <h1 className="font-display text-4xl">Create account</h1>
        <div className="grid grid-cols-2 gap-4">
          <div><Label>First name</Label><Input value={f.firstName} onChange={set("firstName")} /></div>
          <div><Label>Last name</Label><Input value={f.lastName} onChange={set("lastName")} /></div>
        </div>
        <div><Label>Username</Label><Input value={f.username} onChange={set("username")} /></div>
        <div className="grid grid-cols-2 gap-4">
          <div><Label>Phone number</Label><Input type="tel" value={f.phone} onChange={set("phone")} /></div>
          <div><Label>Email</Label><Input type="email" value={f.email} onChange={set("email")} /></div>
        </div>
        <div><Label>Delivery address</Label><Textarea value={f.address} onChange={set("address")} placeholder="House, street, city, postcode" /></div>
        <p className="-mt-2 text-xs text-muted-foreground">You can add a second address later in My Account.</p>
        <div><Label>Password</Label><Input type="password" value={f.password} onChange={set("password")} /></div>
        <Button type="submit" className="w-full">Create account</Button>
        <p className="text-center text-sm text-muted-foreground">Already have an account? <Link to="/signin" className="text-primary">Sign in</Link></p>
      </form>
    </div>
  );
}
