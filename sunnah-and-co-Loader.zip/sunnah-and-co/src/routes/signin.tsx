import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { toast } from "sonner";
import { useStore } from "@/lib/store";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

export const Route = createFileRoute("/signin")({
  head: () => ({
    meta: [
      { title: "Sign In — Sunnah & Co." },
      { name: "description", content: "Sign in to your Sunnah & Co. account." },
      { property: "og:title", content: "Sign In — Sunnah & Co." },
      { property: "og:description", content: "Sign in to your account." },
    ],
  }),
  component: SignIn,
});

function SignIn() {
  const { signIn } = useStore();
  const navigate = useNavigate();
  const [id, setId] = useState("");
  const [pw, setPw] = useState("");
  return (
    <div className="flex justify-center px-6 py-16">
      <form
        className="w-full max-w-md space-y-4 rounded-lg border-t-4 border-gold bg-card p-8 shadow-sm"
        onSubmit={(e) => {
          e.preventDefault();
          const err = signIn(id, pw);
          if (err) { toast.error(err); return; }
          toast.success("Welcome back!");
          navigate({ to: "/" });
        }}
      >
        <h1 className="font-display text-4xl">Sign In</h1>
        <div><Label>Username or email</Label><Input value={id} onChange={(e) => setId(e.target.value)} required /></div>
        <div><Label>Password</Label><Input type="password" value={pw} onChange={(e) => setPw(e.target.value)} required /></div>
        <Button type="submit" className="w-full">Sign In</Button>
        <p className="text-center text-sm text-muted-foreground">New here? <Link to="/signup" className="text-primary">Create an account</Link></p>
      </form>
    </div>
  );
}
