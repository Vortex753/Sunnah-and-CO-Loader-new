# Sunnah & Co.

E-commerce prototype for an Islamic store: books and e-books, clothing, head wear and accessories for men, women and kids.

Built with TanStack Start, React 19, TypeScript, Tailwind CSS v4 and Radix UI. Started from a Lovable export.

## Features
- Sidebar and top navigation with Books, Men, Women, Kids and Accessories dropdowns
- Category pages made of separate topic sections, with a "Jump to" filter that scrolls to the section
- E-books with Add To Cart, About the book, and a download after purchase
- Guest browsing; sign in or sign up to add to cart (up to 2 saved addresses)
- Cart, checkout, order tracking (5 stages) and post-delivery reviews
- Home, About Us, Get in Touch (with FAQ) and footer content

## Getting started
```bash
npm install --legacy-peer-deps   # or: bun install
npm run dev
```
Build for production: `npm run build`.

## Single-file preview
Builds the whole site into one self-contained HTML file you can open directly in a browser:
```bash
npm run build:preview     # outputs prev-dist/index.html
```
`sunnah-preview.html` in the repo root is a ready-built copy. The preview build uses hash URLs (`#/products`) and is configured in `vite.preview.config.ts`.

## Project structure
```
src/lib/data.ts          categories, navigation tree, sample products
src/lib/store.tsx        cart, auth, orders and reviews (localStorage)
src/components/Layout.tsx  sidebar, top bar, footer
src/routes/              pages (home, products, about, contact, cart, checkout, orders, account, signin, signup)
src/styles.css           theme colors and typography
```

## Notes
- Products, prices, descriptions and contact details are placeholder content to be replaced with the client's real data.
- Product images are monogram placeholders until real photos are provided.
- Accounts, carts and orders are stored in the browser (localStorage); there is no backend yet.
